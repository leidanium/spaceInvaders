function Invarders(x, y, id) {
    this.id = id;
    this.x = x;
    this.y = y;
}